#We start by importing all the neccessary modules

from tkinter import Tk, Canvas, PhotoImage, Label, Button, Entry, messagebox
from random import randint
import time
from datetime import datetime

#Creating a window
window = Tk()
window.title("Game")
window.geometry("1200x720")
window.config(bg="black")

#This function displays widgets on home screen
def start():
	#Deletes any other widgets if present
	for widget in window.winfo_children():
		widget.destroy()

	#displaying heading
	label1 = Label(window,
	               text = "PIZZA-ON-A-PLATE"
	               )
	label1.place(x=600, 
		         y=50, 
		         anchor="center"
		         )
	label1.config(fg="yellow")
	label1.config(bg="black")
	label1.config(font = ("Lucida Grande", 60))

	#creating start button
	btn1 = Button(window,
		          text="START", 
		          command=savedornot
		          )
	btn1.config(fg="yellow",bg="red")
	btn1.place(x=550, y=300)

	#creating leaderboards button
	btn2 = Button(window,text="LEADERBOARDS", 
		         command=leaderboards
		         )
	btn2.config(fg="yellow",bg="red")
	btn2.place(x=550, y=450)

	#creating help button
	btn3 = Button(window, 
		          text="HELP", 
		          command=guide
		          )
	btn3.config(fg="yellow", bg="red") 
	btn3.place(x=550, y=600)

#this function resets values of all variables when game is replayed
def reset():
	global score_final
	score_final = 0
	global name
	name = ""
	global drops
	drops = 5 
	global ctr
	ctr = 0 
	global cheat 
	cheat = False
	global cheat2 
	cheat2 = False
	global cheat4
	cheat4 = False
	global running
	running = False

#This function displays the leaderboards
def leaderboards():
	for widget in window.winfo_children():
		widget.destroy()
	file1 = open("leaderboards.txt", "r")
	read_file1 = file1.read()
	list_= []
	list_scores = []
	l9 = Label(window, text="LEADERBOARD")
	l9.place(x=600, y=50, anchor="center")
	l9.config(fg="cyan")
	l9.config(bg="black")
	l9.config(font = ("Lucida Grande",50))
	if len(read_file1) != 0:
		for word in read_file1.split():
			list_.append(word)
		for i in list_:   #all words in list
			for j in i:   #all characters in word
				if j in '1234567890':
					list_scores.append(int(i))  #if word is a number then it appends to list
					break
		sorted_list = sorted(list_scores)  #sorts scores in ascending order
		if len(sorted_list) == 1:       #checks if only one element in list
			top1 = sorted_list[-1]
			top1_position = list_.index(str(top1))
			name1 = list_[top1_position-1]
			position = Label(window, 
				             text="1.", 
				             font="Times 30", 
				             fg="white", 
				             bg="black"
				             )
			position.place(x=350, y=180)
			name_1 = Label(window, 
				           text=name1, 
				           font="Times 30", 
				           fg="white", 
				           bg="black"
				           )
			name_1.place(x=550, y=180)
			score_1 = Label(window, 
				            text=top1, 
				            font="Times 30", 
				            fg="white", 
				            bg="black"
				            )
			score_1.place(x=750, y=180)
		elif len(sorted_list) == 2:      #checks if only two elements in list
			top1 = sorted_list[-1]
			top1_position = list_.index(str(top1))
			name1 = list_[top1_position-1]
			position1 = Label(window, 
				              text="1.", 
				              font="Times 30", 
				              fg="white", 
				              bg="black"
				              )
			position1.place(x=350, y=180)
			name_1 = Label(window, 
				           text=name1, 
				           font="Times 30", 
				           fg="white",
				           bg="black"
				           )
			name_1.place(x=550, y=180)
			score_1 = Label(window, 
				            text=top1, 
				            font="Times 30", 
				            fg="white", 
				            bg="black"
				            )
			score_1.place(x=750, y=180)
			top2 = sorted_list[-2]
			if top2 == top1:
				top2_position = list_.index(str(top2), top1_position+1)
			else:
				top2_position = list_.index(str(top2))
			name2 = list_[top2_position-1]
			position2 = Label(window, 
				              text="2.", 
				              font="Times 30", 
				              fg="white", 
				              bg="black"
				              )
			position2.place(x=350, y=360)
			name_2 = Label(window, 
				           text=name2, 
				           font="Times 30", 
				           fg="white", 
				           bg="black"
				           )
			name_2.place(x=550, y=360)
			score_2 = Label(window, 
				            text=top2, 
				            font="Times 30", 
				            fg="white", 
				            bg="black"
				            )
			score_2.place(x=750, y=360)
		else:                               #checks for top 3 scorers
			top1 = sorted_list[-1]
			top1_position = list_.index(str(top1))
			name1 = list_[top1_position-1]
			position1 = Label(window, 
				              text="1.", 
				              font="Times 30", 
				              fg="white", 
				              bg="black"
				              )
			position1.place(x=350, y=180)
			name_1 = Label(window, 
				           text=name1, 
				           font="Times 30", 
				           fg="white", 
				           bg="black")
			name_1.place(x=550, y=180)
			score_1 = Label(window, 
				            text=top1, 
				            font="Times 30", 
				            fg="white", 
				            bg="black"
				            )
			score_1.place(x=750, y=180)
			top2 = sorted_list[-2]
			if top2 == top1:
				top2_position = list_.index(str(top2),top1_position+1)
			else:
				top2_position = list_.index(str(top2))
			name2 = list_[top2_position-1]
			position2 = Label(window, 
				              text="2.", 
				              font="Times 30", 
				              fg="white", 
				              bg="black"
				              )
			position2.place(x=350, y=360)
			name_2 = Label(window, 
				           text=name2, 
				           font="Times 30", 
				           fg="white", 
				           bg="black"
				           )
			name_2.place(x=550, y=360)
			score_2 = Label(window,
			                text=top2, 
			                font="Times 30", 
			                fg="white", 
			                bg="black"
			                )
			score_2.place(x=750, y=360)
			top3 = sorted_list[-3]
			if top3 == top2:
				top3_position = list_.index(str(top3), top2_position+1)
			else:
				top3_position = list_.index(str(top3))
			name3 = list_[top3_position-1]
			position3 = Label(window,
			                  text="3.", 
			                  font="Times 30", 
			                  fg="white", 
			                  bg="black"
			                  )
			position3.place(x=350, y=540)
			name_3 = Label(window, 
				           text=name3, 
				           font="Times 30", 
				           fg="white", 
				           bg="black"
				           )
			name_3.place(x=550, y=540)
			score_3 = Label(window, 
				            text=top3, 
				            font="Times 30", 
				            fg="white", 
				            bg="black"
				            )
			score_3.place(x=750, y=540)
		btn = Button(window, text="RETURN", command=start)
		btn.place(x=980, y=660)

#This function displays content on clicking help button
def guide():
	for widget in window.winfo_children():
		widget.destroy()
	text_= "You have to catch PIZZA-ON-A-PLATE!!!"
	label2 = Label(window,
	               text=text_, 
	               font="Times 28", 
	               fg="white", 
	               bg="black"
	               )
	label2.place(x=50, y=40)
	text3 = "You can move the plate using left and right arrow keys"
	label3 = Label(window,
	               text=text3,
	               font="Times 28", 
	               fg="white", 
	               bg="black"
	               )
	label3.place(x=50, y=140)
	text4 = "or any other keys that you can set up before you start the game."
	label3 = Label(window, 
		           text=text4, 
		           font="Times 28", 
		           fg="white", 
		           bg="black"
		           )
	label3.place(x=50, y=240)
	text5 = "But this won't be easy as speed of pizza increases with time."
	label4 = Label(window, 
		           text=text5, 
		           font="Times 28", 
		           fg="white", 
		           bg="black"
		           )
	label4.place(x=50, y=340)
	text6 = "Enjoy this mouth-watering game"
	label5 = Label(window, 
		          text=text6, 
		          font="Times 28", 
		          fg="white", 
		          bg="black"
		          )
	label5.place(x=50, y=440)
	text7 = "GOOD LUCK!!!"
	label6 = Label(window, 
		           text=text7, 
		           font="Times 28", 
		           fg="white", 
		           bg="black"
		           )
	label6.place(x=50, y=540)
	text8 = "P.S. <F1> is the boss key. Cheat codes : press the button "
	label7 = Label(window, 
		           text=text8, 
		           font="Times 12", 
		           fg="white", 
		           bg="black"
		           )
	label7.place(x=50, y=660)
	btn_cheat = Button(window, 
		               text="cheat codes", 
		               command=display_cheat_codes
		               )
	btn_cheat.place(x=660, y=660)
	btn = Button(window, text="RETURN", command=start)
	btn.place(x=980, y=660)


#this function displays cheat codes
def display_cheat_codes():
	for widget in window.winfo_children():
		widget.destroy()
	text1 = "1.  Press <space> then <p> to make plate move faster"
	text2 = "2.  Press <space> then <s> to make scores increase by 20"
	text3 = "3,  Press <space> then <q> to make scores increase by 30"
	text4 = "4.  Press <space> then <c> to reduce speed of falling pizzas"
	label1 = Label(window,
	               text=text1,
	               font="Times 28", 
	               fg="white", 
	               bg="black"
	               )
	label1.place(x=50, y=140)
	label2 = Label(window, 
		           text=text2, 
		           font="Times 28", 
		           fg="white", bg="black"
		           )
	label2.place(x=50, y=240)
	label3 = Label(window, 
		           text=text3, 
		           font="Times 28", 
		           fg="white", 
		           bg="black")
	label3.place(x=50, y=340)
	label4 = Label(window,
	               text=text4, 
	               font="Times 28", 
	               fg="white", 
	               bg="black"
	               )
	label4.place(x=50, y=440)
	btn = Button(window, text="RETURN", command=guide)
	btn.place(x=980, y=660)

#this function checks whether there is unfinished game or not
def savedornot():
	file2 = open("saved.txt", "r")
	contents = file2.read()
	if len(contents) == 0:    #if there is no saved data then game starts normally
		username()
	else:
		for widget in window.winfo_children():
			widget.destroy()
		label1 = Label(window, 
			           text="Do you wish to continue previous game?",
		               font = "Times 30", 
		               fg="white", 
		               bg="black"
		               )
		label1.place(x=200, y=100)	
		btn = Button(window, text="START NEW GAME", command=username)
		btn.place(x=350, y=500)
		btn = Button(window, text="CONTINUE GAME", command=continuegame)
		btn.place(x=750, y=500)

#This function assigns neccessary values to variables if user wants to continue previous game
def continuegame():
	global file2
	file2 = open("saved.txt", "r")
	contents = file2.read()
	list_ = []
	score_ = []
	drop_ = []
	for i in contents.split(' '): 
		list_.append(i)
	for j in list_:
		if j.isalpha() == True:  #saving name
			global name
			name = j 
		elif j not in ' ':
			num = int(j)
			if num > 5:    #as drops num is always 5 or less than 5
				score_.append(num)
			else:          #as score is always 10 or greater
				drop_.append(num)
	sorted_score_ = sorted(score_)
	sorted_drop_ = sorted(drop_)
	global score_final
	if len(sorted_score_) != 0:
		score_final = sorted_score_[-1]  #saves last saved score
	else:
		score_final=0
	global drops
	if len(sorted_drop_) != 0:  #saves last saved drop
		drops = sorted_drop_[0]
	else:
		drops = 5
	file2 = open("saved.txt", "w")
	global leftkeyentered
	global rightkeyentered
	leftkeyentered = False
	rightkeyentered = False
	game_start()

#This function accepts user name and keys
def username():
	global file2
	file2 = open("saved.txt", "w")
	for widget in window.winfo_children():
		widget.destroy()
	label1 = Label(window, text="Enter your name", fg="white", bg="black")
	label1.place(x=200, y=100)
	text_ = "Enter Left and/or Right key (if you wish to press specific key)"
	text_ += " else default is Left and Right arrow key"
	key = Label(window, text=text_, fg="white", bg="black")
	key.place(x=100, y=300)
	global entry1
	entry1 = Entry(window)
	entry1.place(x=450, y=100)
	global entry2 
	entry2 = Entry(window)
	entry2.place(x=100, y=500)
	global entry3 
	entry3 = Entry(window)
	entry3.place(x=350, y=500)
	label2 = Label(window, text="Left Key", fg="white", bg="black")
	label2.place(x=100, y=400)
	label3 = Label(window, text="Right Key", fg="white", bg="black")
	label3.place(x=350, y=400)
	btn = Button(window, text="START GAME", command=check_input)
	btn.place(x=350, y=600)

#this function check if user entered name or not and shows error if not entered
def check_input():
	global name
	name = entry1.get()
	if len(name) == 0:  #shows error if user didn't enter name
		messagebox.showerror("Error", "Please Enter Name")
		username()
	else:
		file2.write(name)
		file2.write(' ')
		global Key1
		Key1 = entry2.get()
		global Key2
		Key2 = entry3.get()
		global leftkeyentered
		global rightkeyentered
		if len(Key1) == 0:
			leftkeyentered = False
		else:
			leftkeyentered = True 
		if len(Key2) == 0:
			rightkeyentered = False
		else:
			rightkeyentered = True 
		game_start()

score_final = 0	

#This function starts the game and displays widgets
def game_start():
	for widget in window.winfo_children():
			widget.destroy()
	global canvas2
	global score_final
	global scoreText
	global txt 
	global running
	running = True
	canvas2 = Canvas(window, width=1200, height=720)
	canvas2.pack()
	canvas2.config(bg="brown") 
	btn_pause = Button(canvas2, text="Pause", command=pause, anchor="nw")
	btn_pause.pack()
	btn_window = canvas2.create_window(40, 30, window=btn_pause)
	btn_resume = Button(canvas2, text="Resume", command=resume, anchor="nw")
	btn_resume.pack()
	btn_window = canvas2.create_window(45, 100, window=btn_resume)
	txt = "Score:" + str(score_final)
	scoreText = canvas2.create_text(600,
	                                10, 
	                                fill="white", 
	                                font="Times 20 italic bold", 
	                                text=txt
	                                )
	global plate
	plate = canvas2.create_oval(960,660,660,610,fill="white")	
	move()
	pizza_()

drops = 5	
dropped = False

#This function creates pizza
def pizza_():
	global drops
	global dropped
	global img
	img = PhotoImage(file="pizza2_.png")
	while drops > 0 and running == True:  #continues creating pizzas till 5 chances
		if dropped == True:
			drops -= 1
			file2.write(str(drops))
			file2.write(' ')
			dropped = False
			if drops == 0:
				print("game over")
				game_over()
		elif dropped != True:
			x = randint(100, 1150)
			y = 100		
			global pizza
			pizza = canvas2.create_image(x, y, image=img)
			move_pizza()	

#This function performs final instructions when game is over
def game_over():
	file1 = open("leaderboards.txt", "a")
	file1.write('\n')
	file1.write(name)   #saves name
	file1.write('\n')
	file1.write(str(score_final)) #saves final score
	file1.close()
	global file2
	file2 = open("saved.txt",'r+')
	file2.truncate(0)
	file2.close()
	msg = messagebox.showerror(" ","GAME OVER")
	canvas2.destroy()
	start()
	reset()

#This function pauses the game
def pause():
	global running
	global drops
	drops += 1
	running = False

#The function resumes the game
def resume():
	global running
	running = True
	move()
	pizza_()

ctr = 0

#This function moves the pizza
def move_pizza():
	#global pos
	global collided
	global drops
	global dropped
	global collided
	global ctr
	collided = False
	pos = canvas2.coords(pizza)
	x = pos[0]
	y = pos[1]
	while y < 600 and running == True:
		canvas2.move(pizza, 0, 5)
		window.update()
		if ctr < 5:                #to increase speed gradully
			time.sleep(0.02)
		elif ctr >= 5 and ctr <= 15:
			time.sleep(0.01)
		elif ctr > 15:
			time.sleep(0.005)
		collision()  
		y += 5
	if collided == False:
		canvas2.delete(pizza)
		ctr += 1
		dropped = True 

#This function detects collision
def collision():
	global collided
	global ctr
	pos = canvas2.coords(plate)
	coll = canvas2.find_overlapping(pos[0], pos[1], pos[2], pos[3])
	if len(coll) > 1:
		canvas2.delete(pizza)
		ctr += 1
		collided = True
		dropped = False
		score_ = 10
		score(score_)
		coll = ()

cheat2 = False
cheat4 = False

#This function calculates score
def score(score_):
	global score_final
	global scoreText
	global txt 
	if cheat2 == True:
		score_final += score_ + 10
	elif cheat4 == True:
		score_final += score_ + 20
	else:
		score_final += score_
	file2.write(str(score_final))
	file2.write(' ')
	txt = "score:" + str(score_final)
	canvas2.itemconfigure(scoreText, text = txt)

cheat = False 

#This function enables plate to move
def move():
	global leftkeyentered
	global rightkeyentered
	if running == True:
		if leftkeyentered == True and rightkeyentered == True:
			window.bind([Key1], leftKey)
			window.bind([Key2], rightKey)
		elif leftkeyentered == True and rightkeyentered == False:
			window.bind('<Key>', leftKey)
			window.bind('<Right>', rightKey)
		elif rightkeyentered == True and leftkeyentered==False:
			window.bind('<Key>', rightKey)
			window.bind('<Left>', leftKey)
		else:
			window.bind('<Left>', leftKey)
			window.bind('<Right>', rightKey)


#This function enables plate to move left direction
def leftKey(event):
	if cheat == True:
		x = -50
		y = 0
		canvas2.move(plate, x, y)
	else:
		x = -30
		y = 0
		canvas2.move(plate, x, y)

#This function enables plate to move right direction
def rightKey(event):
	if cheat == True:
		p = 50
		q = 0
		canvas2.move(plate, p, q)
	else:
		p = 30
		q = 0
		canvas2.move(plate, p, q)

#This function implements boss key
def boss(event):
	pause()
	popup = Tk()
	popup.title("Document")
	popup.geometry("1600x900")
	popup.config(bg="white")
	text1 = "Agile scrum methodology is used by companies of all sizes for "
	text1 += "its ability to provide high-end collaboration and efficiency "
	text1 += "for project-based work."
	label1 = Label(popup, bg="white", text=text1)
	label1.place(x=50, y=100)
	text2 = "Agile and scrum are two different methods and can be used"
	text2 += " separately; however, their combined benefits make the"
	text2 += "agile scrum methodology"
	label2 = Label(popup, bg="white", text=text2)
	label2.place(x=50, y=120)
	text3 = "Agile scrum methodology is a project management system that "
	text3 += "relies on incremental development."
	label3 = Label(popup,bg="white", text=text3)
	label3.place(x=50, y=160)
	text4 = "Each iteration consists of two- to four-week sprints,"
	text4 += " where the goal of each sprint is to build the most important"
	text4 += " features first and come out with a deliverable product."
	label4 = Label(popup, bg="white", text=text4)
	label4.place(x=50, y=180)
	text5 = "It encourages products to be built faster, since each set"
	text5 += " of goals must be completed within each sprint's time frame."
	label5 = Label(popup, bg="white", text=text5)
	label5.place(x=50, y=200)
	text6 = "Scrum is a type of agile technology that consists of meetings,"
	text6 += " roles, and tools to help teams working on complex projects"
	text6 += " collaborate and better structure and manage their workload."
	label6 = Label(popup, bg="white", text=text6)
	label6.place(x=50, y=240)
	text7 = "Scrum methodology is ideal for projects that require teams to "
	text7 += "complete a backlog."
	label7 = Label(popup, bg="white", text=text7)
	label7.place(x=50, y=260)
	text8 = "Scrum is also beneficial to companies that value results "
	text8 += "over the documented progress of the process."
	label8 = Label(popup, bg="white", text=text8)
	label8.place(x=50, y=280)
	popup.mainloop()

#The following functions implement cheat code
def cheatcode(event):
	global cheat
	cheat = True

def cheatcode2(event):
	global cheat2 
	cheat2 = True

def cheatcode3(event):
	global ctr 
	ctr = 0

def cheatcode4(event):
	global cheat4
	cheat4 = True

#following commands bind keys to implement boss key and cheat codes
window.bind('<F1>', boss)
window.bind('<space>p', cheatcode)
window.bind('<space>s', cheatcode2)
window.bind('<space>c', cheatcode3)
window.bind('<space>q', cheatcode4)

start()
window.mainloop()